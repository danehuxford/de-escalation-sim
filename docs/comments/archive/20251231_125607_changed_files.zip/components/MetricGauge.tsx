"use client";

import React from "react";

type MetricGaugeProps = {
  label: string;
  value: number;
  min?: number;
  max?: number;
  size?: number;
  showValue?: boolean;
  detail?: string;
};

const clamp = (value: number, min: number, max: number) =>
  Math.min(Math.max(value, min), max);

export default function MetricGauge({
  label,
  value,
  min = 0,
  max = 100,
  size = 160,
  showValue = true,
  detail
}: MetricGaugeProps) {
  const safeValue = clamp(value, min, max);
  const ratio = (safeValue - min) / (max - min || 1);
  const angle = -90 + ratio * 180;

  const strokeWidth = 10;
  const radius = size / 2 - strokeWidth;
  const center = size / 2;
  const pivotY = center;
  const topY = center - radius;
  const leftX = center - radius;
  const rightX = center + radius;

  const arcPath = `M ${leftX} ${pivotY} A ${radius} ${radius} 0 0 1 ${rightX} ${pivotY}`;
  const leftArc = `M ${leftX} ${pivotY} A ${radius} ${radius} 0 0 1 ${center} ${topY}`;
  const rightArc = `M ${center} ${topY} A ${radius} ${radius} 0 0 1 ${rightX} ${pivotY}`;

  const needleLength = radius - 12;
  const tickAngles = [-90, -45, 0, 45, 90];
  const tickOuter = radius + 2;
  const tickInner = radius - 8;
  const neutralTickInner = radius - 12;
  const neutralTickOuter = radius + 4;

  return (
    <div
      className="flex flex-col items-center gap-2"
      aria-label={`${label} ${Math.round(safeValue)} out of 100`}
    >
      <svg width={size} height={size / 2 + 16} viewBox={`0 0 ${size} ${size / 2 + 16}`}>
        <defs>
          <linearGradient
            id={`${label}-left-gradient`}
            x1={leftX}
            y1={center}
            x2={center}
            y2={topY}
            gradientUnits="userSpaceOnUse"
          >
            <stop offset="0%" stopColor="#f87171" stopOpacity="0.7" />
            <stop offset="100%" stopColor="#ef4444" stopOpacity="0.9" />
          </linearGradient>
          <linearGradient
            id={`${label}-right-gradient`}
            x1={center}
            y1={topY}
            x2={rightX}
            y2={center}
            gradientUnits="userSpaceOnUse"
          >
            <stop offset="0%" stopColor="#22c55e" stopOpacity="0.85" />
            <stop offset="100%" stopColor="#4ade80" stopOpacity="0.9" />
          </linearGradient>
          <filter id={`${label}-needle-shadow`} x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="0" dy="2" stdDeviation="2" floodColor="#0f172a" floodOpacity="0.6" />
          </filter>
        </defs>
        <path
          d={arcPath}
          stroke="#1f2937"
          strokeWidth={strokeWidth}
          fill="none"
          strokeLinecap="round"
          opacity={0.5}
        />
        <path
          d={leftArc}
          stroke={`url(#${label}-left-gradient)`}
          strokeWidth={strokeWidth}
          fill="none"
          strokeLinecap="round"
        />
        <path
          d={rightArc}
          stroke={`url(#${label}-right-gradient)`}
          strokeWidth={strokeWidth}
          fill="none"
          strokeLinecap="round"
        />
        {tickAngles.map((tickAngle) => {
          const radians = (Math.PI / 180) * tickAngle;
          const isNeutral = tickAngle === 0;
          const outer = isNeutral ? neutralTickOuter : tickOuter;
          const inner = isNeutral ? neutralTickInner : tickInner;
          const x1 = center + outer * Math.cos(radians);
          const y1 = pivotY + outer * Math.sin(radians);
          const x2 = center + inner * Math.cos(radians);
          const y2 = pivotY + inner * Math.sin(radians);
          return (
            <line
              key={tickAngle}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke={isNeutral ? "#e2e8f0" : "#64748b"}
              strokeWidth={isNeutral ? 2 : 1}
              opacity={isNeutral ? 0.9 : 0.6}
            />
          );
        })}
        <g
          transform={`rotate(${angle} ${center} ${pivotY})`}
          style={{ transition: "transform 300ms cubic-bezier(0.2, 0.8, 0.2, 1)" }}
        >
          <line
            x1={center}
            y1={pivotY}
            x2={center}
            y2={pivotY - needleLength}
            stroke="#e5e7eb"
            strokeWidth={2.5}
            strokeLinecap="round"
            filter={`url(#${label}-needle-shadow)`}
          />
        </g>
        <circle cx={center} cy={pivotY} r={7} fill="#0f172a" opacity={0.7} />
        <circle cx={center} cy={pivotY} r={4} fill="#e5e7eb" />
      </svg>
      <div className="text-base font-semibold text-slate-200">{label}</div>
      {showValue && (
        <div className="text-xs text-slate-400">
          {Math.round(safeValue)}
          {detail ? (
            <div className="text-[11px] text-slate-500">{detail}</div>
          ) : null}
        </div>
      )}
    </div>
  );
}
