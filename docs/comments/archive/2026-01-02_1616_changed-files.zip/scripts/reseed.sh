#!/usr/bin/env bash
set -euo pipefail

if [[ "${NODE_ENV:-development}" == "production" ]]; then
  echo "Refusing to reseed in production."
  exit 1
fi

DB_URL="${SUPABASE_DB_URL:-${DATABASE_URL:-}}"
if [[ -z "${DB_URL}" ]]; then
  echo "Missing SUPABASE_DB_URL or DATABASE_URL."
  exit 1
fi

if rg -n "\\\\'" db/seed.sql >/dev/null 2>&1; then
  echo "Invalid escaping found in db/seed.sql."
  echo "Use doubled single quotes ('') instead of \\' in SQL string literals."
  exit 1
fi

if ! command -v psql >/dev/null 2>&1; then
  echo "psql is required to run db/schema.sql and db/seed.sql."
  exit 1
fi

psql "${DB_URL}" -f db/schema.sql -f db/seed.sql
