insert into departments (name, code, description, is_active)
values
  ('Emergency Department', 'ED', 'Front-line emergency care unit.', true),
  ('Intensive Care Unit', 'ICU', 'Critical care for high-acuity patients.', true),
  ('Billing/Registration', 'BILLING_REG', 'Financial intake and coverage support.', true)
on conflict (code) do update
set
  name = excluded.name,
  description = excluded.description,
  is_active = excluded.is_active;

insert into scenarios (
  department_id,
  scenario_type,
  title,
  summary,
  description,
  difficulty,
  tags,
  persona_seed,
  constraints_refs,
  is_active,
  is_published
)
select
  (select id from departments where code = 'ED'),
  'LONG_WAIT_DELAY',
  'Six-Hour Wait Escalation',
  'A patient escalates after extended waiting with no updates.',
  'Patient is angry about the wait time and demands immediate attention.',
  'Standard',
  array['wait', 'delay'],
  jsonb_build_object('persona', 'Anxious patient', 'mood', 'frustrated'),
  null,
  true,
  true
where not exists (
  select 1
  from scenarios
  where title = 'Six-Hour Wait Escalation'
    and department_id = (select id from departments where code = 'ED')
);

insert into scenarios (
  department_id,
  scenario_type,
  title,
  summary,
  description,
  difficulty,
  tags,
  persona_seed,
  constraints_refs,
  is_active,
  is_published
)
select
  (select id from departments where code = 'ED'),
  'POLICY_VS_COMPASSION',
  'Policy vs Compassion',
  'A visitor limit policy clashes with a family request.',
  'Family insists on bending the visitor policy for a critical moment.',
  'Standard',
  array['policy', 'family'],
  jsonb_build_object('persona', 'Stressed family member', 'mood', 'urgent'),
  null,
  true,
  true
where not exists (
  select 1
  from scenarios
  where title = 'Policy vs Compassion'
    and department_id = (select id from departments where code = 'ED')
);

insert into scenarios (
  department_id,
  scenario_type,
  title,
  summary,
  description,
  difficulty,
  tags,
  persona_seed,
  constraints_refs,
  is_active,
  is_published
)
select
  (select id from departments where code = 'ICU'),
  'FAMILY_DISTRESS',
  'Family at the Bedside',
  'A family member is overwhelmed and presses for constant updates.',
  'Family is anxious about a loved one and keeps interrupting care.',
  'Standard',
  array['family', 'distress'],
  jsonb_build_object('persona', 'Worried sibling', 'mood', 'anxious'),
  null,
  true,
  true
where not exists (
  select 1
  from scenarios
  where title = 'Family at the Bedside'
    and department_id = (select id from departments where code = 'ICU')
);

insert into scenarios (
  department_id,
  scenario_type,
  title,
  summary,
  description,
  difficulty,
  tags,
  persona_seed,
  constraints_refs,
  is_active,
  is_published
)
select
  (select id from departments where code = 'ICU'),
  'POLICY_VS_COMPASSION',
  'Quiet Hours Enforcement',
  'A caregiver challenges ICU quiet-hour limits.',
  'Visitor asks to stay past quiet hours to speak with the physician.',
  'Standard',
  array['policy', 'icu'],
  jsonb_build_object('persona', 'Caregiver', 'mood', 'worried'),
  null,
  true,
  true
where not exists (
  select 1
  from scenarios
  where title = 'Quiet Hours Enforcement'
    and department_id = (select id from departments where code = 'ICU')
);

insert into scenarios (
  department_id,
  scenario_type,
  title,
  summary,
  description,
  difficulty,
  tags,
  persona_seed,
  constraints_refs,
  is_active,
  is_published
)
select
  (select id from departments where code = 'BILLING_REG'),
  'BILLING_DISPUTE',
  'Unexpected Copay Dispute',
  'A patient disputes an unexpected copay at registration.',
  'Patient believes the copay is wrong and demands a waiver.',
  'Standard',
  array['billing', 'copay'],
  jsonb_build_object('persona', 'Patient', 'mood', 'irritated'),
  null,
  true,
  true
where not exists (
  select 1
  from scenarios
  where title = 'Unexpected Copay Dispute'
    and department_id = (select id from departments where code = 'BILLING_REG')
);

insert into scenarios (
  department_id,
  scenario_type,
  title,
  summary,
  description,
  difficulty,
  tags,
  persona_seed,
  constraints_refs,
  is_active,
  is_published
)
select
  (select id from departments where code = 'BILLING_REG'),
  'INSURANCE_DENIAL',
  'Coverage Denied',
  'A patient is upset about a denied insurance claim.',
  'Patient insists coverage should apply and wants immediate resolution.',
  'Standard',
  array['billing', 'insurance'],
  jsonb_build_object('persona', 'Family advocate', 'mood', 'upset'),
  null,
  true,
  true
where not exists (
  select 1
  from scenarios
  where title = 'Coverage Denied'
    and department_id = (select id from departments where code = 'BILLING_REG')
);
