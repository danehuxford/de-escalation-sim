import { getSupabaseClient } from "../supabaseClient";
import type { Scenario } from "../types";

export async function fetchPublishedScenarios(options?: {
  departmentId?: string;
}): Promise<{
  data: Scenario[] | null;
  error: string | null;
}> {
  const client = getSupabaseClient();
  if (!client) {
    return { data: null, error: "Supabase client not configured." };
  }

  let query = client
    .from("scenarios")
    .select("*")
    .eq("is_published", true)
    .eq("is_active", true);

  if (options?.departmentId) {
    query = query.eq("department_id", options.departmentId);
  }

  const { data, error } = await query.order("created_at", { ascending: false });

  return { data: (data as Scenario[]) ?? null, error: error?.message ?? null };
}

export async function fetchScenarioById(
  scenarioId: string
): Promise<{ data: Scenario | null; error: string | null }> {
  const client = getSupabaseClient();
  if (!client) {
    return { data: null, error: "Supabase client not configured." };
  }

  const { data, error } = await client
    .from("scenarios")
    .select("*")
    .eq("id", scenarioId)
    .single();

  return { data: (data as Scenario) ?? null, error: error?.message ?? null };
}
