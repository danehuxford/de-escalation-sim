"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { fetchScenarioById } from "../../../lib/db/scenarios";
import {
  fetchSessionMetrics,
  fetchTurnMetricsByTurnId,
  updateSessionMetricsWithDeltas,
  createTurnMetrics
} from "../../../lib/db/metrics";
import {
  endSession,
  fetchSessionById,
  incrementTurnCount
} from "../../../lib/db/sessions";
import {
  createCoachTurn,
  createTurn,
  fetchTurnsBySessionId
} from "../../../lib/db/turns";
import { buildCoachResponse } from "../../../lib/coach";
import { computeTurnMetrics } from "../../../lib/scoring";
import type { Scenario, Session, SessionMetrics, Turn } from "../../../lib/types";

type PageProps = {
  params: { sessionId: string };
};

export default function SimulationPage({ params }: PageProps) {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);
  const [scenario, setScenario] = useState<Scenario | null>(null);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [metrics, setMetrics] = useState<SessionMetrics | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [isEnding, setIsEnding] = useState(false);

  const sessionId = useMemo(() => params.sessionId, [params.sessionId]);
  const userTurnCount = useMemo(
    () => turns.filter((turn) => turn.role === "user").length,
    [turns]
  );

  const clamp = (value: number, min: number, max: number) =>
    Math.min(Math.max(value, min), max);

  useEffect(() => {
    let isMounted = true;

    const loadSession = async () => {
      setIsLoading(true);
      const { data: sessionData, error: sessionError } =
        await fetchSessionById(sessionId);

      if (!isMounted) {
        return;
      }

      if (sessionError || !sessionData) {
        setError(sessionError ?? "Session not found.");
        setSession(null);
        setScenario(null);
        setTurns([]);
        setIsLoading(false);
        return;
      }

      const [
        { data: scenarioData, error: scenarioError },
        turnsResult,
        metricsResult
      ] = await Promise.all([
        fetchScenarioById(sessionData.scenario_id),
        fetchTurnsBySessionId(sessionId),
        fetchSessionMetrics(sessionId)
      ]);

      if (!isMounted) {
        return;
      }

      let errorMessage: string | null = null;

      if (scenarioError || !scenarioData) {
        errorMessage = scenarioError ?? "Scenario not found.";
        setScenario(null);
      } else {
        setScenario(scenarioData);
      }

      if (turnsResult.error) {
        errorMessage = errorMessage ?? turnsResult.error;
        setTurns([]);
      } else {
        setTurns(turnsResult.data ?? []);
      }

      if (metricsResult.error) {
        errorMessage = errorMessage ?? metricsResult.error;
        setMetrics(null);
      } else {
        setMetrics(metricsResult.data);
      }

      setSession(sessionData);
      setError(errorMessage);
      setIsLoading(false);
    };

    loadSession();

    return () => {
      isMounted = false;
    };
  }, [sessionId]);

  const handleSend = async () => {
    if (!session || !input.trim()) {
      return;
    }

    setIsSending(true);
    setError(null);
    const trimmedInput = input.trim();
    const { deltas, reasons } = computeTurnMetrics(trimmedInput);
    const nextUserTurnCount = session.turn_count + 1;

    const { data, error: turnError } = await createTurn(
      session.id,
      "user",
      trimmedInput
    );

    if (turnError || !data) {
      setError(turnError ?? "Unable to send message.");
      setIsSending(false);
      return;
    }

    const { data: createdTurnMetrics, error: turnMetricsError } =
      await createTurnMetrics(session.id, data.id, deltas, reasons);
    if (turnMetricsError) {
      setError(turnMetricsError);
    }

    const { data: metricsData, error: metricsError } =
      await updateSessionMetricsWithDeltas(session.id, deltas);
    if (metricsError) {
      setError(metricsError);
    } else if (metricsData) {
      setMetrics(metricsData);
    }

    const { error: incrementError } = await incrementTurnCount(session.id);
    if (incrementError) {
      setError(incrementError);
    }

    const { data: latestMetrics, error: metricsFetchError } =
      await fetchSessionMetrics(session.id);
    if (metricsFetchError) {
      setError(metricsFetchError);
    } else if (latestMetrics) {
      setMetrics(latestMetrics);
    }

    const { data: latestTurnMetrics, error: turnMetricsFetchError } =
      createdTurnMetrics
        ? { data: createdTurnMetrics, error: null }
        : await fetchTurnMetricsByTurnId(data.id);
    if (turnMetricsFetchError) {
      setError(turnMetricsFetchError);
    }

    const finalMetrics = metricsData ?? latestMetrics ?? metrics;
    const finalTurnMetrics = latestTurnMetrics;

    const buildDeltaBadges = (turnMetrics: typeof finalTurnMetrics) => {
      if (!turnMetrics) {
        return "ΔE:+0 ΔC:+0 ΔB:+0 ΔEsc:+0";
      }
      const formatDelta = (value: number) => `${value >= 0 ? "+" : ""}${value}`;
      return [
        `ΔE:${formatDelta(turnMetrics.empathy_delta)}`,
        `ΔC:${formatDelta(turnMetrics.clarity_delta)}`,
        `ΔB:${formatDelta(turnMetrics.boundary_delta)}`,
        `ΔEsc:${formatDelta(turnMetrics.escalation_delta)}`
      ].join(" ");
    };

    const formatCoachContent = (coach: {
      category: string;
      tip: string;
      rewrite: string;
      next_step: string;
      why: string;
      deltas?: string;
    }) => {
      const safeCategory = coach.category?.trim() || "Neutral";
      const safeWhy = coach.why?.trim() || "delta based on scoring rules";
      const safeTip = coach.tip?.trim() || "Add validation and one clear next step.";
      const safeRewrite =
        coach.rewrite?.trim() ||
        "I hear you. Here's what I can do next: [action]. I'll update you in [time].";
      const safeNextStep =
        coach.next_step?.trim() || "Next step: ask one clarifying question.";
      const deltaBadges = buildDeltaBadges(finalTurnMetrics);
      return [
        `Category: ${safeCategory} (${deltaBadges})`,
        `Tip: ${safeTip}`,
        `Why: ${safeWhy}`,
        `Rewrite: ${safeRewrite}`,
        `Next step: ${safeNextStep}`
      ].join("\n");
    };

    let patientTurn: Turn | null = null;
    let coachTurn: Turn | null = null;
    let needsFallbackPatient = false;
    let needsFallbackCoach = false;

    if (finalMetrics && finalTurnMetrics && !metricsError) {
      const transcript = [...turns, data]
        .slice(-12)
        .map((turn) => ({ role: turn.role, content: turn.content }));
      const state = {
        arousal: clamp(finalMetrics.escalation_level, 0, 5),
        trust: clamp(
          Math.round(
            (finalMetrics.empathy_score + finalMetrics.boundary_score) / 40
          ),
          0,
          5
        )
      };

      try {
        const response = await fetch("/api/sim/next", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            sessionId: session.id,
            scenario,
            transcript,
            metrics: finalMetrics,
            lastTurnMetrics: finalTurnMetrics,
            state
          })
        });

        if (!response.ok) {
          throw new Error("AI response not available.");
        }

        const aiPayload = (await response.json()) as {
          patient?: string;
          coach?: {
            category: string;
            tip: string;
            rewrite: string;
            next_step: string;
            why: string;
            deltas?: string;
          };
        };

        if (!aiPayload.patient || !aiPayload.coach) {
          throw new Error("AI response missing patient or coach.");
        }

        const { data: patientData, error: patientError } = await createTurn(
          session.id,
          "patient",
          aiPayload.patient
        );
        if (patientError) {
          console.error("Patient turn insert failed.", patientError);
          needsFallbackPatient = true;
        } else {
          patientTurn = patientData;
        }

        const coachContent = formatCoachContent(aiPayload.coach);
        const { data: coachData, error: coachError } = await createCoachTurn(
          session.id,
          coachContent,
          aiPayload.coach.category,
          aiPayload.coach.tip,
          aiPayload.coach.rewrite
        );
        if (coachError) {
          console.error("Coach turn insert failed.", coachError);
          needsFallbackCoach = true;
        } else {
          coachTurn = coachData;
        }
      } catch (aiError) {
        console.error("AI response failed.", aiError);
        needsFallbackPatient = true;
        needsFallbackCoach = true;
      }
    } else {
      needsFallbackPatient = true;
      needsFallbackCoach = true;
    }

    if (needsFallbackCoach && finalTurnMetrics) {
      const fallbackCoach = buildCoachResponse(
        finalTurnMetrics,
        nextUserTurnCount
      );
      const { data: coachData, error: coachError } = await createCoachTurn(
        session.id,
        fallbackCoach.content,
        fallbackCoach.category,
        fallbackCoach.tip,
        fallbackCoach.rewrite
      );
      if (coachError) {
        console.error("Coach turn insert failed.", coachError);
      } else {
        coachTurn = coachData;
      }
    }

    if (needsFallbackPatient) {
      const { data: patientData, error: patientError } = await createTurn(
        session.id,
        "patient",
        "(Patient response unavailable - AI offline.)"
      );
      if (patientError) {
        console.error("Patient turn insert failed.", patientError);
      } else {
        patientTurn = patientData;
      }
    }

    setSession((prev) =>
      prev ? { ...prev, turn_count: prev.turn_count + 1 } : prev
    );
    setTurns((prev) => [
      ...prev,
      data,
      ...(patientTurn ? [patientTurn] : []),
      ...(coachTurn ? [coachTurn] : [])
    ]);
    setInput("");
    setIsSending(false);
  };

  const handleEndSession = async () => {
    if (!session) {
      return;
    }

    setIsEnding(true);
    setError(null);

    const { error: endError } = await endSession(
      session.id,
      "Session ended by participant."
    );

    if (endError) {
      setError(endError);
      setIsEnding(false);
      return;
    }

    router.push(`/results/${session.id}`);
  };

  if (isLoading) {
    return (
      <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6">
        <h1 className="text-2xl font-semibold">Loading session...</h1>
        <p className="mt-2 text-sm text-slate-300">
          Fetching session details and transcript.
        </p>
      </div>
    );
  }

  if (!session || !scenario) {
    return (
      <div className="rounded-2xl border border-dashed border-slate-700 bg-slate-900/70 p-6">
        <h1 className="text-2xl font-semibold">Simulation Not Found</h1>
        <p className="mt-2 text-sm text-slate-300">
          This session id does not exist or is unavailable.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6">
        <div className="text-xs uppercase tracking-wide text-slate-400">
          Session {session.id}
        </div>
        <h1 className="mt-2 text-2xl font-semibold">{scenario.title}</h1>
        <p className="mt-2 text-sm text-slate-300">
          {scenario.description ?? "No description provided yet."}
        </p>
        <div className="mt-4 flex flex-wrap gap-2 text-xs text-slate-300">
          <span className="rounded-full border border-slate-700 px-3 py-1">
            Outcome: {session.outcome}
          </span>
          <span className="rounded-full border border-slate-700 px-3 py-1">
            Turns: {userTurnCount}
          </span>
          <span className="rounded-full border border-slate-700 px-3 py-1">
            Started: {session.started_at}
          </span>
        </div>
      </section>

      {error && (
        <section className="rounded-2xl border border-rose-500/40 bg-rose-500/10 p-4 text-sm text-rose-200">
          {error}
        </section>
      )}

      <section className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6">
        <h2 className="text-lg font-semibold">Metrics</h2>
        {metrics ? (
          <div className="mt-4 grid gap-3 text-sm text-slate-300 sm:grid-cols-2">
            <div>Empathy: {metrics.empathy_score}/100</div>
            <div>Clarity: {metrics.clarity_score}/100</div>
            <div>Boundaries: {metrics.boundary_score}/100</div>
            <div>Escalation: Level {metrics.escalation_level}/5</div>
          </div>
        ) : (
          <p className="mt-3 text-sm text-slate-400">
            Metrics are not available yet.
          </p>
        )}
      </section>

      <section className="rounded-2xl border border-slate-800 bg-slate-900 p-6">
        <h2 className="text-lg font-semibold">Simulation Chat</h2>
        <div className="mt-4 space-y-4">
          {turns.map((turn) => {
            const baseClasses = "rounded-xl p-4";
            const roleClasses =
              turn.role === "coach"
                ? "border border-emerald-500/40 bg-emerald-500/10"
                : turn.role === "patient"
                ? "border border-amber-500/40 bg-amber-500/10"
                : turn.role === "system"
                ? "border border-slate-700 bg-slate-950/60"
                : "bg-slate-950/60";
            const roleLabel = turn.role.toUpperCase();

            return (
              <div key={turn.id} className={`${baseClasses} ${roleClasses}`}>
                <div className="text-xs uppercase tracking-wide text-slate-400">
                  {roleLabel} · {turn.created_at}
                </div>
                <p className="mt-2 whitespace-pre-line text-sm text-slate-100">
                  {turn.content}
                </p>
              </div>
            );
          })}
          {turns.length === 0 && (
            <div className="rounded-xl border border-dashed border-slate-700 p-4 text-sm text-slate-400">
              No turns yet. Start the conversation when ready.
            </div>
          )}
        </div>
        <div className="mt-6 space-y-3">
          <textarea
            value={input}
            onChange={(event) => setInput(event.target.value)}
            className="min-h-[120px] w-full rounded-xl border border-slate-700 bg-slate-950/60 p-3 text-sm text-slate-100"
            placeholder="Type the next facilitator prompt..."
          />
          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={handleSend}
              className="rounded-full bg-cyan-400 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-slate-950 transition hover:bg-cyan-300 disabled:cursor-not-allowed disabled:opacity-60"
              disabled={isSending || !input.trim()}
            >
              {isSending ? "Sending..." : "Send"}
            </button>
            <button
              type="button"
              onClick={handleEndSession}
              className="rounded-full border border-slate-600 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-slate-100 transition hover:border-slate-400 disabled:cursor-not-allowed disabled:opacity-60"
              disabled={isEnding}
            >
              {isEnding ? "Ending..." : "End Session"}
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
