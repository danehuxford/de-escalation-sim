"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { fetchPublishedScenarios } from "../lib/db/scenarios";
import { createSession } from "../lib/db/sessions";
import { upsertSessionMetrics } from "../lib/db/metrics";
import { createTurn } from "../lib/db/turns";
import { getAnonId } from "../lib/anonId";
import type { Scenario } from "../lib/types";

export default function ScenarioLibraryPage() {
  const router = useRouter();
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [startingScenarioId, setStartingScenarioId] = useState<string | null>(
    null
  );

  useEffect(() => {
    let isMounted = true;

    const loadScenarios = async () => {
      setIsLoading(true);
      const { data, error: fetchError } = await fetchPublishedScenarios();
      if (!isMounted) {
        return;
      }

      if (fetchError) {
        setError(fetchError);
        setScenarios([]);
      } else {
        setError(null);
        setScenarios(data ?? []);
      }
      setIsLoading(false);
    };

    loadScenarios();

    return () => {
      isMounted = false;
    };
  }, []);

  const handleStart = async (scenario: Scenario) => {
    setStartingScenarioId(scenario.id);
    setError(null);

    const anonId = getAnonId();
    if (!anonId) {
      setError("Anonymous id unavailable in this environment.");
      setStartingScenarioId(null);
      return;
    }

    const { data, error: createError } = await createSession(
      scenario.id,
      anonId
    );

    if (createError || !data) {
      setError(createError ?? "Unable to start session.");
      setStartingScenarioId(null);
      return;
    }

    const openingLine = scenario.description
      ? `Begin ${scenario.title}: ${scenario.description}`
      : `Begin ${scenario.title}.`;
    const { error: turnError } = await createTurn(
      data.id,
      "system",
      openingLine,
      { source: "system" }
    );

    if (turnError) {
      setError(turnError);
      setStartingScenarioId(null);
      return;
    }

    const { error: metricsError } = await upsertSessionMetrics(data.id);
    if (metricsError) {
      setError(metricsError);
      setStartingScenarioId(null);
      return;
    }

    router.push(`/sim/${data.id}`);
  };

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6">
        <h1 className="text-2xl font-semibold">Scenario Library</h1>
        <p className="mt-2 text-sm text-slate-300">
          Browse available ED calm simulations and launch a session.
        </p>
      </section>

      {isLoading && (
        <section className="rounded-2xl border border-slate-800 bg-slate-900 p-6 text-sm text-slate-300">
          Loading published scenarios...
        </section>
      )}

      {error && (
        <section className="rounded-2xl border border-rose-500/40 bg-rose-500/10 p-6 text-sm text-rose-200">
          {error}
        </section>
      )}

      {!isLoading && !error && scenarios.length === 0 && (
        <section className="rounded-2xl border border-dashed border-slate-700 bg-slate-900/70 p-6 text-sm text-slate-300">
          No published scenarios available yet.
        </section>
      )}

      <section className="grid gap-4 md:grid-cols-2">
        {scenarios.map((scenario) => (
          <article
            key={scenario.id}
            className="rounded-2xl border border-slate-800 bg-slate-900 p-5 shadow-lg"
          >
            <div className="text-xs uppercase tracking-wide text-slate-400">
              {scenario.difficulty ?? "Standard"}
            </div>
            <h2 className="mt-2 text-lg font-semibold text-white">
              {scenario.title}
            </h2>
            <p className="mt-2 text-sm text-slate-300">
              {scenario.description ?? "No description provided yet."}
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {(scenario.tags ?? []).map((tag) => (
                <span
                  key={tag}
                  className="rounded-full bg-slate-800 px-3 py-1 text-xs text-slate-200"
                >
                  {tag}
                </span>
              ))}
            </div>
            <div className="mt-5 text-sm">
              <button
                type="button"
                onClick={() => handleStart(scenario)}
                className="rounded-full bg-cyan-400 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-slate-950 transition hover:bg-cyan-300 disabled:cursor-not-allowed disabled:opacity-60"
                disabled={startingScenarioId === scenario.id}
              >
                {startingScenarioId === scenario.id ? "Starting..." : "Start"}
              </button>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}
