export type Scenario = {
  id: string;
  title: string;
  description: string | null;
  difficulty: string | null;
  tags: string[];
  is_published: boolean;
  created_at: string;
};

export type Session = {
  id: string;
  scenario_id: string;
  anon_id: string;
  started_at: string;
  ended_at: string | null;
  turn_count: number;
  outcome: string;
  summary: string | null;
  created_at: string;
};

export type Turn = {
  id: string;
  session_id: string;
  role: "user" | "coach" | "system" | "patient";
  content: string;
  coach_category: string | null;
  coach_tip: string | null;
  coach_rewrite: string | null;
  source: "ai" | "repaired" | "heuristic" | "user" | "system" | null;
  model: string | null;
  prompt_hash: string | null;
  created_at: string;
};

export type SessionMetrics = {
  session_id: string;
  empathy_score: number;
  clarity_score: number;
  boundary_score: number;
  escalation_level: number;
  updated_at: string;
};

export type TurnMetrics = {
  id: string;
  session_id: string;
  turn_id: string;
  empathy_delta: number;
  clarity_delta: number;
  boundary_delta: number;
  escalation_delta: number;
  reasons: (string | { metric: string; delta: number; rule: string })[] | null;
  created_at: string;
};

export type TurnMetricsDeltas = Pick<
  TurnMetrics,
  "empathy_delta" | "clarity_delta" | "boundary_delta" | "escalation_delta"
>;
