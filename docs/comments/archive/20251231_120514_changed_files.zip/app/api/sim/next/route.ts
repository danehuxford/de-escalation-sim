// app/api/sim/next/route.ts
import { NextResponse } from "next/server";
import fs from "node:fs";
import path from "node:path";

type ReqBody = {
  sessionId: string;
  scenario?: Record<string, unknown>;
  transcript?: Array<{ role: string; content: string }>;
  state?: { arousal: number; trust: number };
  metrics?: {
    empathy_score: number;
    clarity_score: number;
    boundary_score: number;
    escalation_level: number;
  };
  lastTurnMetrics?: {
    empathy_delta: number;
    clarity_delta: number;
    boundary_delta: number;
    escalation_delta: number;
    reasons?: unknown;
  };
};

function readPromptFile(): string {
  // You already have: docs/prompts/ed_gpt_patient_coach.md
  const p = path.join(process.cwd(), "docs", "prompts", "ed_gpt_patient_coach.md");
  return fs.readFileSync(p, "utf8");
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as ReqBody;

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "Missing OPENAI_API_KEY" }, { status: 500 });
    }

    const systemPrompt = readPromptFile();

    // IMPORTANT: tell the model to output JSON only.
    const userPrompt = {
      sessionId: body.sessionId,
      scenario: body.scenario ?? null,
      currentState: body.state ?? { arousal: 5, trust: 0 },
      sessionMetrics: body.metrics ?? {
        empathy_score: 50,
        clarity_score: 50,
        boundary_score: 50,
        escalation_level: 2
      },
      lastTurnMetrics: body.lastTurnMetrics ?? null,
      transcript: body.transcript?.slice(-12) ?? [],
      output_contract:
        "Return ONLY valid JSON with keys: patient, coach{category,tip,rewrite,next_step,why,deltas}."
    };

    // Call OpenAI (use your preferred client; this is fetch-based and simple)
    const resp = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.COACH_MODEL || "gpt-4.1",
        input: [
          { role: "system", content: systemPrompt + "\n\nOUTPUT MUST BE JSON ONLY." },
          { role: "user", content: JSON.stringify(userPrompt) }
        ]
      })
    });

    if (!resp.ok) {
      const errText = await resp.text();
      return NextResponse.json({ error: "OpenAI error", detail: errText }, { status: 500 });
    }

    const data = await resp.json();

    // Depending on API shape, the text may be in different places.
    // We’ll try common paths; Codex can refine this after you run it once.
    const text =
      data.output_text ??
      data?.output?.[0]?.content?.[0]?.text ??
      data?.response?.output_text;

    if (!text) {
      return NextResponse.json({ error: "No model text returned", raw: data }, { status: 500 });
    }

    let parsed: any;
    try {
      parsed = JSON.parse(text);
    } catch {
      return NextResponse.json({ error: "Model did not return valid JSON", text }, { status: 500 });
    }

    return NextResponse.json(parsed);
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Unknown error" }, { status: 500 });
  }
}
