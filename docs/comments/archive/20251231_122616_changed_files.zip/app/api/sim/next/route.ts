// app/api/sim/next/route.ts
import { NextResponse } from "next/server";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { buildCoachResponse } from "../../../../lib/coach";
import type { TurnMetrics } from "../../../../lib/types";

type ReqBody = {
  sessionId: string;
  scenario?: Record<string, unknown>;
  transcript?: Array<{ role: string; content: string }>;
  state?: { arousal: number; trust: number };
  metrics?: {
    empathy_score: number;
    clarity_score: number;
    boundary_score: number;
    escalation_level: number;
  };
  lastTurnMetrics?: {
    empathy_delta: number;
    clarity_delta: number;
    boundary_delta: number;
    escalation_delta: number;
    reasons?: unknown;
  };
};

type CoachPayload = {
  category: string;
  tip: string;
  rewrite: string;
  next_step: string;
  why: string;
  deltas: string;
};

const PROMPT_PATH = path.join(
  process.cwd(),
  "docs",
  "prompts",
  "ed_gpt_patient_coach.md"
);

function readPromptFile(): string {
  return fs.readFileSync(PROMPT_PATH, "utf8");
}

function hashPrompt(prompt: string): string {
  return crypto.createHash("sha256").update(prompt).digest("hex");
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}

function formatDeltaBadges(metrics: ReqBody["lastTurnMetrics"]): string {
  const formatValue = (value: number) => `${value >= 0 ? "+" : ""}${value}`;
  return [
    `ΔE:${formatValue(metrics?.empathy_delta ?? 0)}`,
    `ΔC:${formatValue(metrics?.clarity_delta ?? 0)}`,
    `ΔB:${formatValue(metrics?.boundary_delta ?? 0)}`,
    `ΔEsc:${formatValue(metrics?.escalation_delta ?? 0)}`
  ].join(" ");
}

function normalizeCategory(category: string): string {
  const normalized = category.trim();
  const allowed = ["Escalation", "Empathy", "Boundary", "Clarity", "Neutral"];
  if (allowed.includes(normalized)) {
    return normalized;
  }
  return "Neutral";
}

function isValidCoachPayload(payload: any): payload is CoachPayload {
  if (!payload || typeof payload !== "object") {
    return false;
  }
  const fields = ["category", "tip", "rewrite", "next_step", "why"];
  return fields.every(
    (field) => isNonEmptyString(payload[field]) && payload[field] !== "undefined"
  );
}

function buildTurnMetricsForCoach(
  lastTurnMetrics: ReqBody["lastTurnMetrics"]
): TurnMetrics {
  return {
    id: "ai",
    session_id: "ai",
    turn_id: "ai",
    empathy_delta: lastTurnMetrics?.empathy_delta ?? 0,
    clarity_delta: lastTurnMetrics?.clarity_delta ?? 0,
    boundary_delta: lastTurnMetrics?.boundary_delta ?? 0,
    escalation_delta: lastTurnMetrics?.escalation_delta ?? 0,
    reasons: Array.isArray(lastTurnMetrics?.reasons)
      ? lastTurnMetrics?.reasons
      : null,
    created_at: new Date().toISOString()
  };
}

function normalizeCoachPayload(
  payload: any,
  lastTurnMetrics: ReqBody["lastTurnMetrics"],
  userTurnCount: number
): CoachPayload {
  const deltaBadges = formatDeltaBadges(lastTurnMetrics);
  if (isValidCoachPayload(payload)) {
    return {
      category: normalizeCategory(payload.category),
      tip: payload.tip.trim(),
      rewrite: payload.rewrite.trim(),
      next_step: payload.next_step.trim(),
      why: payload.why.trim(),
      deltas: deltaBadges
    };
  }

  const coachTurnMetrics = buildTurnMetricsForCoach(lastTurnMetrics);
  const fallback = buildCoachResponse(coachTurnMetrics, userTurnCount);
  return {
    category: normalizeCategory(fallback.category),
    tip: fallback.tip,
    rewrite: fallback.rewrite,
    next_step: fallback.nextStep,
    why: "delta based on scoring rules",
    deltas: deltaBadges
  };
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as ReqBody;

    let systemPrompt = "";
    let promptHash = "";
    let aiAttempted = false;
    let aiSucceeded = false;
    let source: "ai" | "repaired" | "heuristic" = "heuristic";
    const model = process.env.COACH_MODEL || "gpt-4.1";

    try {
      systemPrompt = readPromptFile();
      promptHash = hashPrompt(systemPrompt);
    } catch (error) {
      if (process.env.NODE_ENV !== "production") {
        throw new Error(
          "Missing prompt file: docs/prompts/ed_gpt_patient_coach.md"
        );
      }
      systemPrompt =
        "You are a safe, calm ED patient simulation. Respond briefly.";
      promptHash = hashPrompt(systemPrompt);
      const fallbackTurnMetrics = buildTurnMetricsForCoach(body.lastTurnMetrics);
      const fallbackCoach = buildCoachResponse(
        fallbackTurnMetrics,
        body.transcript?.filter((turn) => turn.role === "user").length ?? 0
      );
      const coach = {
        category: fallbackCoach.category,
        tip: fallbackCoach.tip,
        rewrite: fallbackCoach.rewrite,
        next_step: fallbackCoach.nextStep,
        why: "delta based on scoring rules",
        deltas: formatDeltaBadges(body.lastTurnMetrics)
      };
      const patient = "(Patient response unavailable - AI offline.)";
      return NextResponse.json({
        patient,
        coach,
        metrics: body.metrics ?? null,
        lastTurnMetrics: body.lastTurnMetrics ?? null,
        meta: {
          ai_attempted: false,
          ai_succeeded: false,
          model,
          prompt_hash: promptHash,
          prompt_path: "docs/prompts/ed_gpt_patient_coach.md",
          source: "heuristic"
        }
      });
    }

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "Missing OPENAI_API_KEY" }, { status: 500 });
    }

    // IMPORTANT: tell the model to output JSON only.
    const userPrompt = {
      sessionId: body.sessionId,
      scenario: body.scenario ?? null,
      currentState: body.state ?? { arousal: 5, trust: 0 },
      sessionMetrics: body.metrics ?? {
        empathy_score: 50,
        clarity_score: 50,
        boundary_score: 50,
        escalation_level: 2
      },
      lastTurnMetrics: body.lastTurnMetrics ?? null,
      transcript: body.transcript?.slice(-12) ?? [],
      output_contract:
        "Return ONLY valid JSON with keys: patient, coach{category,tip,rewrite,next_step,why,deltas}."
    };

    // Call OpenAI (use your preferred client; this is fetch-based and simple)
    aiAttempted = true;
    const resp = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model,
        input: [
          { role: "system", content: systemPrompt + "\n\nOUTPUT MUST BE JSON ONLY." },
          { role: "user", content: JSON.stringify(userPrompt) }
        ]
      })
    });

    if (!resp.ok) {
      const errText = await resp.text();
      return NextResponse.json({ error: "OpenAI error", detail: errText }, { status: 500 });
    }

    const data = await resp.json();

    // Depending on API shape, the text may be in different places.
    // We’ll try common paths; Codex can refine this after you run it once.
    const text =
      data.output_text ??
      data?.output?.[0]?.content?.[0]?.text ??
      data?.response?.output_text;

    if (!text) {
      return NextResponse.json({ error: "No model text returned", raw: data }, { status: 500 });
    }

    let parsed: any;
    try {
      parsed = JSON.parse(text);
    } catch {
      return NextResponse.json({ error: "Model did not return valid JSON", text }, { status: 500 });
    }

    const patient = isNonEmptyString(parsed?.patient)
      ? parsed.patient.trim()
      : "(Patient response unavailable - AI offline.)";
    const userTurnCount =
      body.transcript?.filter((turn) => turn.role === "user").length ?? 0;
    const coach = normalizeCoachPayload(
      parsed?.coach,
      body.lastTurnMetrics,
      userTurnCount
    );
    aiSucceeded =
      isValidCoachPayload(parsed?.coach) && isNonEmptyString(parsed?.patient);
    source = aiSucceeded ? "ai" : "repaired";

    if (process.env.NODE_ENV !== "production") {
      console.log(
        `sim-next session=${body.sessionId} source=${source} model=${model} prompt=${promptHash.slice(
          0,
          8
        )}`
      );
    }

    return NextResponse.json({
      patient,
      coach,
      metrics: body.metrics ?? null,
      lastTurnMetrics: body.lastTurnMetrics ?? null,
      meta: {
        ai_attempted: aiAttempted,
        ai_succeeded: aiSucceeded,
        model,
        prompt_hash: promptHash,
        prompt_path: "docs/prompts/ed_gpt_patient_coach.md",
        source
      }
    });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Unknown error" }, { status: 500 });
  }
}
function hashPrompt(prompt: string): string {
  return crypto.createHash("sha256").update(prompt).digest("hex");
}
