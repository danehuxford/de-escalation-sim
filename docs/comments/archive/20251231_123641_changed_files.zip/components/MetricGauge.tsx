"use client";

import React from "react";

type MetricGaugeProps = {
  label: string;
  value: number;
  min?: number;
  max?: number;
  size?: number;
  showValue?: boolean;
};

const clamp = (value: number, min: number, max: number) =>
  Math.min(Math.max(value, min), max);

export default function MetricGauge({
  label,
  value,
  min = 0,
  max = 100,
  size = 160,
  showValue = true
}: MetricGaugeProps) {
  const safeValue = clamp(value, min, max);
  const ratio = (safeValue - min) / (max - min || 1);
  const angle = -90 + ratio * 180;

  const strokeWidth = 12;
  const radius = size / 2 - strokeWidth;
  const center = size / 2;
  const topY = center - radius;
  const leftX = center - radius;
  const rightX = center + radius;

  const leftArc = `M ${leftX} ${center} A ${radius} ${radius} 0 0 1 ${center} ${topY}`;
  const rightArc = `M ${center} ${topY} A ${radius} ${radius} 0 0 1 ${rightX} ${center}`;

  const needleLength = radius - 6;

  return (
    <div className="flex flex-col items-center gap-2">
      <svg width={size} height={size / 2 + 16} viewBox={`0 0 ${size} ${size / 2 + 16}`}>
        <path
          d={`M ${leftX} ${center} A ${radius} ${radius} 0 0 1 ${rightX} ${center}`}
          stroke="#1f2937"
          strokeWidth={strokeWidth}
          fill="none"
          strokeLinecap="round"
        />
        <path
          d={leftArc}
          stroke="#ef4444"
          strokeWidth={strokeWidth}
          fill="none"
          strokeLinecap="round"
        />
        <path
          d={rightArc}
          stroke="#22c55e"
          strokeWidth={strokeWidth}
          fill="none"
          strokeLinecap="round"
        />
        <g
          style={{
            transform: `rotate(${angle}deg)`,
            transformOrigin: `${center}px ${center}px`,
            transition: "transform 250ms ease-out"
          }}
        >
          <line
            x1={center}
            y1={center}
            x2={center}
            y2={center - needleLength}
            stroke="#e5e7eb"
            strokeWidth={3}
            strokeLinecap="round"
          />
        </g>
        <circle cx={center} cy={center} r={5} fill="#e5e7eb" />
      </svg>
      <div className="text-sm font-semibold text-slate-200">{label}</div>
      {showValue && (
        <div className="text-xs text-slate-400">{Math.round(safeValue)}</div>
      )}
    </div>
  );
}
