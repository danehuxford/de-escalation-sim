create table if not exists session_metrics (
  session_id uuid primary key references sessions(id) on delete cascade,
  empathy_score int not null default 50,
  clarity_score int not null default 50,
  boundary_score int not null default 50,
  escalation_level int not null default 2,
  updated_at timestamptz not null default now()
);

create table if not exists turn_metrics (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references sessions(id) on delete cascade,
  turn_id uuid not null references turns(id) on delete cascade,
  empathy_delta int not null default 0,
  clarity_delta int not null default 0,
  boundary_delta int not null default 0,
  escalation_delta int not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists idx_turn_metrics_session_id on turn_metrics(session_id);
create index if not exists idx_turn_metrics_turn_id on turn_metrics(turn_id);

alter table turn_metrics
  add column if not exists reasons jsonb;

alter table turns
  add column if not exists coach_category text,
  add column if not exists coach_tip text,
  add column if not exists coach_rewrite text,
  add column if not exists source text,
  add column if not exists model text,
  add column if not exists prompt_hash text;

do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conname = 'turns_source_check'
  ) then
    alter table turns
      add constraint turns_source_check
      check (source in ('ai', 'repaired', 'heuristic', 'user', 'system'));
  end if;
end $$;
