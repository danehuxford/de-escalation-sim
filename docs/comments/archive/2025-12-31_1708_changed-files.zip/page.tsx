"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { fetchScenarioById } from "../../../lib/db/scenarios";
import {
  fetchSessionMetrics,
  fetchTurnMetricsByTurnId,
  updateSessionMetricsWithDeltas,
  createTurnMetrics
} from "../../../lib/db/metrics";
import {
  endSession,
  fetchSessionById,
  incrementTurnCount
} from "../../../lib/db/sessions";
import {
  createCoachTurn,
  createTurn,
  fetchTurnsBySessionId
} from "../../../lib/db/turns";
import { buildCoachResponse } from "../../../lib/coach";
import { computeTurnMetrics } from "../../../lib/scoring";
import MetricGauge from "../../../components/MetricGauge";
import { getSupabaseClient } from "../../../lib/supabaseClient";
import type { Scenario, Session, SessionMetrics, Turn } from "../../../lib/types";

type PageProps = {
  params: { sessionId: string };
};

type CoachMeSuggestion = {
  id: "light" | "medium" | "strong";
  strength: 1 | 2 | 3;
  label: string;
  phrase: string;
};

export default function SimulationPage({ params }: PageProps) {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);
  const [scenario, setScenario] = useState<Scenario | null>(null);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [metrics, setMetrics] = useState<SessionMetrics | null>(null);
  const [lastTurnMetrics, setLastTurnMetrics] = useState<{
    empathy_delta: number;
    clarity_delta: number;
    boundary_delta: number;
    escalation_delta: number;
    reasons?: unknown;
  } | null>(null);
  const [lastCoachTurnId, setLastCoachTurnId] = useState<string | null>(null);
  const [debugMetricsOverride, setDebugMetricsOverride] = useState<{
    enabled: boolean;
    overall: number;
    empathy: number;
    clarity: number;
    boundaries: number;
    escalation: number;
  }>({
    enabled: false,
    overall: 50,
    empathy: 50,
    clarity: 50,
    boundaries: 50,
    escalation: 50
  });
  const [metricsTunerCollapsed, setMetricsTunerCollapsed] = useState(false);
  const [aiMeta, setAiMeta] = useState<{
    source: string;
    model: string | null;
    prompt_hash: string | null;
  } | null>(null);
  const [isCoachMeOpen, setIsCoachMeOpen] = useState(false);
  const [coachMeMetric, setCoachMeMetric] = useState<
    "empathy" | "clarity" | "boundaries" | "de-escalation"
  >("empathy");
  const [coachMeStrength, setCoachMeStrength] = useState<1 | 2 | 3>(1);
  const [coachMeSuggestions, setCoachMeSuggestions] = useState<
    CoachMeSuggestion[]
  >([]);
  const [coachMeCache, setCoachMeCache] = useState<
    Record<string, CoachMeSuggestion[]>
  >({});
  const [coachMeError, setCoachMeError] = useState<string | null>(null);
  const [coachMeLoading, setCoachMeLoading] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [isEnding, setIsEnding] = useState(false);

  const sessionId = useMemo(() => params.sessionId, [params.sessionId]);
  const userTurnCount = useMemo(
    () => turns.filter((turn) => turn.role === "user").length,
    [turns]
  );

  const clamp = (value: number, min: number, max: number) =>
    Math.min(Math.max(value, min), max);
  const showAiDebug =
    process.env.NODE_ENV !== "production" ||
    process.env.NEXT_PUBLIC_DEBUG_AI === "1";
  const showMetricsTuner =
    process.env.NODE_ENV !== "production" ||
    process.env.NEXT_PUBLIC_DEBUG_METRICS === "1";
  const showCoachMe = process.env.NEXT_PUBLIC_ENABLE_COACH_ME === "true";
  const METRIC_POLARITY = {
    empathy: "higher_better",
    clarity: "higher_better",
    boundaries: "higher_better",
    escalation: "lower_better"
  } as const;

  const escalationLevelToGauge = (level: number) => {
    const safeLevel = clamp(level, 0, 5);
    if (safeLevel <= 1) {
      return 80;
    }
    if (safeLevel === 2) {
      return 60;
    }
    if (safeLevel === 3) {
      return 40;
    }
    if (safeLevel === 4) {
      return 20;
    }
    return 0;
  };

  const gaugeInputs = useMemo(() => {
    if (!metrics) {
      return null;
    }
    const rawValues = {
      empathy: metrics.empathy_score,
      clarity: metrics.clarity_score,
      boundaries: metrics.boundary_score,
      escalation: escalationLevelToGauge(metrics.escalation_level)
    };
    const displayValues = {
      empathy:
        METRIC_POLARITY.empathy === "lower_better"
          ? 100 - rawValues.empathy
          : rawValues.empathy,
      clarity:
        METRIC_POLARITY.clarity === "lower_better"
          ? 100 - rawValues.clarity
          : rawValues.clarity,
      boundaries:
        METRIC_POLARITY.boundaries === "lower_better"
          ? 100 - rawValues.boundaries
          : rawValues.boundaries,
      escalation:
        METRIC_POLARITY.escalation === "lower_better"
          ? 100 - rawValues.escalation
          : rawValues.escalation
    };
    const overall = clamp(
      Math.round(
        0.3 * displayValues.empathy +
          0.25 * displayValues.clarity +
          0.25 * displayValues.boundaries +
          0.2 * displayValues.escalation
      ),
      0,
      100
    );
    const liveValues = { ...displayValues, overall };
    const baseValues = debugMetricsOverride.enabled
      ? debugMetricsOverride
      : liveValues;
    const turnCount = session?.turn_count ?? userTurnCount;
    if (turnCount === 0 && !debugMetricsOverride.enabled) {
      return { ...baseValues, overall: 50, escalation: 50 };
    }
    return baseValues;
  }, [debugMetricsOverride, metrics, session?.turn_count, userTurnCount]);
  const fallbackGaugeValues = gaugeInputs ?? {
    overall: 50,
    empathy: 50,
    clarity: 50,
    boundaries: 50,
    escalation: 50
  };

  const handleOverrideToggle = (enabled: boolean) => {
    if (enabled && !debugMetricsOverride.enabled) {
      setDebugMetricsOverride((prev) => ({
        ...fallbackGaugeValues,
        enabled: true
      }));
      return;
    }
    setDebugMetricsOverride((prev) => ({ ...prev, enabled }));
  };

  const handleOverrideReset = () => {
    setDebugMetricsOverride({ ...fallbackGaugeValues, enabled: false });
  };

  const handleOverrideCenter = () => {
    setDebugMetricsOverride((prev) => ({
      ...prev,
      enabled: true,
      overall: 50,
      empathy: 50,
      clarity: 50,
      boundaries: 50,
      escalation: 50
    }));
  };

  const handleCoachMeRequest = async () => {
    if (!session) {
      return;
    }
    const cacheKey = `${session.turn_count ?? 0}-${coachMeMetric}`;
    if (coachMeCache[cacheKey]) {
      setCoachMeSuggestions(coachMeCache[cacheKey]);
      return;
    }
    setCoachMeLoading(true);
    setCoachMeError(null);
    try {
      const response = await fetch("/api/sim/coach-me", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionId: session.id,
          selectedMetric: coachMeMetric,
          selectedStrength: coachMeStrength
        })
      });
      if (!response.ok) {
        throw new Error("Coach Me unavailable.");
      }
      const data = (await response.json()) as {
        metric: string;
        suggestions: CoachMeSuggestion[];
      };
      const suggestions = data.suggestions ?? [];
      setCoachMeSuggestions(suggestions);
      setCoachMeCache((prev) => ({ ...prev, [cacheKey]: suggestions }));
    } catch (err: any) {
      setCoachMeError(err?.message ?? "Unable to load suggestions.");
    } finally {
      setCoachMeLoading(false);
    }
  };

  useEffect(() => {
    let isMounted = true;

    const loadSession = async () => {
      setIsLoading(true);
      const { data: sessionData, error: sessionError } =
        await fetchSessionById(sessionId);

      if (!isMounted) {
        return;
      }

      if (sessionError || !sessionData) {
        setError(sessionError ?? "Session not found.");
        setSession(null);
        setScenario(null);
        setTurns([]);
        setIsLoading(false);
        return;
      }

      const [
        { data: scenarioData, error: scenarioError },
        turnsResult,
        metricsResult
      ] = await Promise.all([
        fetchScenarioById(sessionData.scenario_id),
        fetchTurnsBySessionId(sessionId),
        fetchSessionMetrics(sessionId)
      ]);

      if (!isMounted) {
        return;
      }

      let errorMessage: string | null = null;

      if (scenarioError || !scenarioData) {
        errorMessage = scenarioError ?? "Scenario not found.";
        setScenario(null);
      } else {
        setScenario(scenarioData);
      }

      if (turnsResult.error) {
        errorMessage = errorMessage ?? turnsResult.error;
        setTurns([]);
      } else {
        setTurns(turnsResult.data ?? []);
      }

      if (metricsResult.error) {
        errorMessage = errorMessage ?? metricsResult.error;
        setMetrics(null);
      } else {
        const baseMetrics = metricsResult.data;
        if (baseMetrics) {
          setMetrics({
            ...baseMetrics,
            empathy_score: 50,
            clarity_score: 50,
            boundary_score: 50,
            escalation_level: 2
          });
        } else {
          setMetrics(baseMetrics);
        }
      }

      setSession(sessionData);
      setError(errorMessage);
      setIsLoading(false);
    };

    loadSession();

    return () => {
      isMounted = false;
    };
  }, [sessionId]);

  useEffect(() => {
    if (!showAiDebug || !metrics) {
      return;
    }
    const turnValue = session?.turn_count ?? userTurnCount;
    console.log(
      `[metrics] E=${metrics.empathy_score} C=${metrics.clarity_score} B=${metrics.boundary_score} Esc=${metrics.escalation_level} (turn=${turnValue})`
    );
  }, [metrics, session?.turn_count, showAiDebug, userTurnCount]);

  useEffect(() => {
    if (!showAiDebug || !metrics || !gaugeInputs) {
      return;
    }
    console.log(
      "[metrics] raw:",
      {
        empathy: metrics.empathy_score,
        clarity: metrics.clarity_score,
        boundaries: metrics.boundary_score,
        escalation: escalationLevelToGauge(metrics.escalation_level)
      },
      "display:",
      {
        overall: gaugeInputs.overall,
        empathy: gaugeInputs.empathy,
        clarity: gaugeInputs.clarity,
        boundaries: gaugeInputs.boundaries,
        escalation: gaugeInputs.escalation
      },
      "polarity:",
      METRIC_POLARITY
    );
  }, [gaugeInputs, metrics, showAiDebug]);

  const handleSend = async () => {
    if (!session || !input.trim()) {
      return;
    }

    setIsSending(true);
    setError(null);
    const trimmedInput = input.trim();
    const { deltas, reasons } = computeTurnMetrics(trimmedInput);
    const nextUserTurnCount = session.turn_count + 1;

    const { data, error: turnError } = await createTurn(
      session.id,
      "user",
      trimmedInput,
      { source: "user" }
    );

    if (turnError || !data) {
      setError(turnError ?? "Unable to send message.");
      setIsSending(false);
      return;
    }

    const { data: createdTurnMetrics, error: turnMetricsError } =
      await createTurnMetrics(session.id, data.id, deltas, reasons);
    if (turnMetricsError) {
      setError(turnMetricsError);
    }

    const { data: metricsData, error: metricsError } =
      await updateSessionMetricsWithDeltas(session.id, deltas);
    if (metricsError) {
      setError(metricsError);
    }

    const { error: incrementError } = await incrementTurnCount(session.id);
    if (incrementError) {
      setError(incrementError);
    }

    const { data: latestMetrics, error: metricsFetchError } =
      await fetchSessionMetrics(session.id);
    if (metricsFetchError) {
      setError(metricsFetchError);
    }

    const { data: latestTurnMetrics, error: turnMetricsFetchError } =
      createdTurnMetrics
        ? { data: createdTurnMetrics, error: null }
        : await fetchTurnMetricsByTurnId(data.id);
    if (turnMetricsFetchError) {
      setError(turnMetricsFetchError);
    }

    const finalMetrics = metricsData ?? latestMetrics ?? metrics;
    const finalTurnMetrics = latestTurnMetrics;

    const buildDeltaBadges = (turnMetrics: typeof finalTurnMetrics) => {
      if (!turnMetrics) {
        return "ΔE:+0 ΔC:+0 ΔB:+0 ΔEsc:+0";
      }
      const formatDelta = (value: number) => `${value >= 0 ? "+" : ""}${value}`;
      return [
        `ΔE:${formatDelta(turnMetrics.empathy_delta)}`,
        `ΔC:${formatDelta(turnMetrics.clarity_delta)}`,
        `ΔB:${formatDelta(turnMetrics.boundary_delta)}`,
        `ΔEsc:${formatDelta(turnMetrics.escalation_delta)}`
      ].join(" ");
    };

    const formatCoachContent = (coach: {
      category: string;
      tip: string;
      rewrite: string;
      next_step: string;
      why: string;
      deltas?: string;
    }) => {
      const safeCategory = coach.category?.trim() || "Neutral";
      const safeWhy = coach.why?.trim() || "delta based on scoring rules";
      const safeTip = coach.tip?.trim() || "Add validation and one clear next step.";
      const safeRewrite =
        coach.rewrite?.trim() ||
        "I hear you. Here's what I can do next: [action]. I'll update you in [time].";
      const safeNextStep =
        coach.next_step?.trim() || "Next step: ask one clarifying question.";
      const deltaBadges = buildDeltaBadges(finalTurnMetrics);
      return [
        `Category: ${safeCategory} (${deltaBadges})`,
        `Tip: ${safeTip}`,
        `Why: ${safeWhy}`,
        `Rewrite: ${safeRewrite}`,
        `Next step: ${safeNextStep}`
      ].join("\n");
    };

    let patientTurn: Turn | null = null;
    let coachTurn: Turn | null = null;
    let needsFallbackPatient = false;
    let needsFallbackCoach = false;

    if (finalMetrics && finalTurnMetrics && !metricsError) {
      const transcript = [...turns, data]
        .slice(-12)
        .map((turn) => ({ role: turn.role, content: turn.content }));
      const state = {
        arousal: clamp(finalMetrics.escalation_level, 0, 5),
        trust: clamp(
          Math.round(
            (finalMetrics.empathy_score + finalMetrics.boundary_score) / 40
          ),
          0,
          5
        )
      };

      try {
        const response = await fetch("/api/sim/next", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            sessionId: session.id,
            scenario,
            transcript,
            metrics: finalMetrics,
            lastTurnMetrics: finalTurnMetrics,
            state
          })
        });

        if (!response.ok) {
          throw new Error("AI response not available.");
        }

        const aiPayload = (await response.json()) as {
          patient?: string;
          coach?: {
            category: string;
            tip: string;
            rewrite: string;
            next_step: string;
            why: string;
            deltas?: string;
          };
          meta?: {
            source: "ai" | "repaired" | "heuristic";
            model: string;
            prompt_hash: string;
          };
          metrics?: SessionMetrics;
          lastTurnMetrics?: {
            empathy_delta: number;
            clarity_delta: number;
            boundary_delta: number;
            escalation_delta: number;
            reasons?: unknown;
          };
        };

        if (!aiPayload.patient || !aiPayload.coach) {
          throw new Error("AI response missing patient or coach.");
        }
        const meta = aiPayload.meta ?? null;
        if (meta) {
          setAiMeta({
            source: meta.source,
            model: meta.model,
            prompt_hash: meta.prompt_hash
          });
        }
        const responseMetrics =
          aiPayload.metrics ?? latestMetrics ?? metricsData ?? null;
        const responseTurnMetrics =
          aiPayload.lastTurnMetrics ?? latestTurnMetrics ?? null;
        if (showAiDebug) {
          console.log("[sim-next coach payload]", aiPayload.coach);
        }

        const isAiSource = meta?.source === "ai" || meta?.source === "repaired";
        const { data: patientData, error: patientError } = await createTurn(
          session.id,
          "patient",
          aiPayload.patient,
          {
            source: meta?.source ?? "heuristic",
            model: isAiSource ? meta?.model ?? null : null,
            prompt_hash: isAiSource ? meta?.prompt_hash ?? null : null
          }
        );
        if (patientError) {
          console.error("Patient turn insert failed.", patientError);
          needsFallbackPatient = true;
        } else {
          patientTurn = patientData;
        }

        const coachContent = formatCoachContent(aiPayload.coach);
        if (showAiDebug) {
          console.log("[sim-next coach insert]", {
            content: coachContent,
            category: aiPayload.coach.category,
            tip: aiPayload.coach.tip,
            why: aiPayload.coach.why,
            rewrite: aiPayload.coach.rewrite,
            next_step: aiPayload.coach.next_step
          });
        }
        const { data: coachData, error: coachError } = await createCoachTurn(
          session.id,
          coachContent,
          aiPayload.coach.category,
          aiPayload.coach.tip,
          aiPayload.coach.rewrite,
          {
            source: meta?.source ?? "heuristic",
            model: isAiSource ? meta?.model ?? null : null,
            prompt_hash: isAiSource ? meta?.prompt_hash ?? null : null
          }
        );
        if (coachError) {
          console.error("Coach turn insert failed.", coachError);
          needsFallbackCoach = true;
        } else {
          coachTurn = coachData;
          setLastCoachTurnId(coachData.id);
          if (showAiDebug) {
            const client = getSupabaseClient();
            if (client) {
              const { data: persisted, error: persistedError } = await client
                .from("turns")
                .select("id, content, coach_tip, coach_rewrite")
                .eq("id", coachData.id)
                .single();
              if (persistedError) {
                console.log("[sim-next coach persisted error]", persistedError);
              } else {
                console.log("[sim-next coach persisted]", persisted);
              }
            }
          }
        }

        const nextTurns = [
          ...turns,
          data,
          ...(patientTurn ? [patientTurn] : []),
          ...(coachTurn ? [coachTurn] : [])
        ];
        setTurns(nextTurns);
        if (responseMetrics) {
          setMetrics(responseMetrics);
        }
        setLastTurnMetrics(responseTurnMetrics);
        setSession((prev) =>
          prev ? { ...prev, turn_count: prev.turn_count + 1 } : prev
        );
        setInput("");
        setIsSending(false);
        return;
      } catch (aiError) {
        console.error("AI response failed.", aiError);
        needsFallbackPatient = true;
        needsFallbackCoach = true;
      }
    } else {
      needsFallbackPatient = true;
      needsFallbackCoach = true;
    }

    if (needsFallbackCoach && finalTurnMetrics) {
      const fallbackCoach = buildCoachResponse(
        finalTurnMetrics,
        nextUserTurnCount
      );
      const { data: coachData, error: coachError } = await createCoachTurn(
        session.id,
        fallbackCoach.content,
        fallbackCoach.category,
        fallbackCoach.tip,
        fallbackCoach.rewrite,
        { source: "heuristic", model: null, prompt_hash: null }
      );
      if (coachError) {
        console.error("Coach turn insert failed.", coachError);
      } else {
        coachTurn = coachData;
        setLastCoachTurnId(coachData.id);
      }
    }

    if (needsFallbackPatient) {
      const { data: patientData, error: patientError } = await createTurn(
        session.id,
        "patient",
        "(Patient response unavailable - AI offline.)",
        { source: "heuristic" }
      );
      if (patientError) {
        console.error("Patient turn insert failed.", patientError);
      } else {
        patientTurn = patientData;
      }
    }

    setSession((prev) =>
      prev ? { ...prev, turn_count: prev.turn_count + 1 } : prev
    );
    const fallbackTurns = [
      ...turns,
      data,
      ...(patientTurn ? [patientTurn] : []),
      ...(coachTurn ? [coachTurn] : [])
    ];
    setTurns(fallbackTurns);
    const fallbackMetrics = latestMetrics ?? metricsData ?? null;
    if (fallbackMetrics) {
      setMetrics(fallbackMetrics);
    }
    setLastTurnMetrics(latestTurnMetrics ?? null);
    setInput("");
    setIsSending(false);
  };

  const handleEndSession = async () => {
    if (!session) {
      return;
    }

    setIsEnding(true);
    setError(null);

    const { error: endError } = await endSession(
      session.id,
      "Session ended by participant."
    );

    if (endError) {
      setError(endError);
      setIsEnding(false);
      return;
    }

    router.push(`/results/${session.id}`);
  };

  if (isLoading) {
    return (
      <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6">
        <h1 className="text-2xl font-semibold">Loading session...</h1>
        <p className="mt-2 text-sm text-slate-300">
          Fetching session details and transcript.
        </p>
      </div>
    );
  }

  if (!session || !scenario) {
    return (
      <div className="rounded-2xl border border-dashed border-slate-700 bg-slate-900/70 p-6">
        <h1 className="text-2xl font-semibold">Simulation Not Found</h1>
        <p className="mt-2 text-sm text-slate-300">
          This session id does not exist or is unavailable.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-slate-800 bg-slate-900/70 p-6">
        <div className="text-xs uppercase tracking-wide text-slate-400">
          Session {session.id}
        </div>
        <h1 className="mt-2 text-2xl font-semibold">{scenario.title}</h1>
        <p className="mt-2 text-sm text-slate-300">
          {scenario.description ?? "No description provided yet."}
        </p>
        <div className="mt-4 flex flex-wrap gap-2 text-xs text-slate-300">
          <span className="rounded-full border border-slate-700 px-3 py-1">
            Outcome: {session.outcome}
          </span>
          <span className="rounded-full border border-slate-700 px-3 py-1">
            Turns: {userTurnCount}
          </span>
          <span className="rounded-full border border-slate-700 px-3 py-1">
            Started: {session.started_at}
          </span>
        </div>
      </section>

      {error && (
        <section className="rounded-2xl border border-rose-500/40 bg-rose-500/10 p-4 text-sm text-rose-200">
          {error}
        </section>
      )}

      <section className="sticky top-4 z-20 rounded-2xl border border-slate-800 bg-slate-900/90 p-6 shadow-lg backdrop-blur-sm">
        <h2 className="text-lg font-semibold">Metrics</h2>
        {showMetricsTuner && (
          <div className="mt-1 text-xs uppercase tracking-wide text-slate-500">
            Debug metrics: {debugMetricsOverride.enabled ? "OVERRIDE" : "LIVE"}
          </div>
        )}
        {metrics ? (
          <div className="mt-5 grid grid-cols-1 place-items-center gap-6 md:grid-cols-2 lg:grid-cols-5">
            <MetricGauge
              label="Overall"
              value={gaugeInputs?.overall ?? 0}
              size={176}
            />
            <MetricGauge label="Empathy" value={gaugeInputs?.empathy ?? 0} />
            <MetricGauge label="Clarity" value={gaugeInputs?.clarity ?? 0} />
            <MetricGauge label="Boundaries" value={gaugeInputs?.boundaries ?? 0} />
            <MetricGauge
              label={
                METRIC_POLARITY.escalation === "lower_better"
                  ? "Calmness"
                  : "Escalation"
              }
              value={gaugeInputs?.escalation ?? 0}
              detail={
                debugMetricsOverride.enabled
                  ? "Override"
                  : `Level ${metrics.escalation_level}/5`
              }
            />
          </div>
        ) : (
          <p className="mt-3 text-sm text-slate-400">
            Metrics are not available yet.
          </p>
        )}
        {showAiDebug && aiMeta && (
          <div className="mt-4 text-[11px] uppercase tracking-wide text-slate-500">
            AI: {aiMeta.source} | model: {aiMeta.model ?? "n/a"} | prompt:{" "}
            {aiMeta.prompt_hash ? aiMeta.prompt_hash.slice(0, 8) : "n/a"}
          </div>
        )}
      </section>

      <section className="rounded-2xl border border-slate-800 bg-slate-900 p-6">
        <h2 className="text-lg font-semibold">Simulation Chat</h2>
        <div className="mt-4 space-y-4">
          {turns.map((turn) => {
            const baseClasses = "rounded-xl p-4";
            const roleClasses =
              turn.role === "coach"
                ? "border border-emerald-500/40 bg-emerald-500/10"
                : turn.role === "patient"
                ? "border border-amber-500/40 bg-amber-500/10"
                : turn.role === "system"
                ? "border border-slate-700 bg-slate-950/60"
                : "bg-slate-950/60";
            const roleLabel = turn.role.toUpperCase();

            const rawCategory =
              turn.coach_category ??
              (turn.content.split("\n")[0]?.replace("Category:", "").trim() ??
                "Neutral");
            const categoryLabel = rawCategory.split("(")[0]?.trim() || "Neutral";
            const shouldUseDeterministicDeltas =
              turn.role === "coach" && turn.id === lastCoachTurnId;
            const deterministicDeltas = lastTurnMetrics;
            const deltaValues = shouldUseDeterministicDeltas && deterministicDeltas
              ? {
                  empathy: deterministicDeltas.empathy_delta,
                  clarity: deterministicDeltas.clarity_delta,
                  boundary: deterministicDeltas.boundary_delta,
                  escalation: deterministicDeltas.escalation_delta
                }
              : null;
            const parsedDeltas = (() => {
              const match = turn.content.match(/\\(ΔE:([^\\s]+)\\s+ΔC:([^\\s]+)\\s+ΔB:([^\\s]+)\\s+ΔEsc:([^\\s]+)\\)/);
              if (!match) {
                return null;
              }
              return {
                empathy: Number(match[2]),
                clarity: Number(match[3]),
                boundary: Number(match[4]),
                escalation: Number(match[5])
              };
            })();
            const deltas = deltaValues ?? parsedDeltas;
            const badgeClass = (delta?: number) => {
              if (typeof delta !== "number" || Number.isNaN(delta)) {
                return "border-slate-700 bg-slate-900/70 text-slate-300";
              }
              if (delta > 0) {
                return "border-emerald-500/40 bg-emerald-500/10 text-emerald-200";
              }
              if (delta < 0) {
                return "border-rose-500/40 bg-rose-500/10 text-rose-200";
              }
              return "border-slate-700 bg-slate-900/70 text-slate-300";
            };
            const contentLines = turn.content.split("\\n");
            const getCoachLine = (prefix: string) =>
              contentLines
                .find((line) => line.startsWith(`${prefix}:`))
                ?.slice(prefix.length + 1)
                .trim();
            const coachFields = {
              tip: turn.coach_tip ?? getCoachLine("Tip"),
              why: getCoachLine("Why"),
              rewrite: turn.coach_rewrite ?? getCoachLine("Rewrite"),
              nextStep: getCoachLine("Next step")
            };
            const detailKeys = [
              coachFields.tip ? "tip" : null,
              coachFields.why ? "why" : null,
              coachFields.rewrite ? "rewrite" : null,
              coachFields.nextStep ? "next" : null
            ].filter(Boolean);
            const fallbackBody = contentLines
              .filter((line) => !line.startsWith("Category:"))
              .join("\\n")
              .trim();

            return (
              <div key={turn.id} className={`${baseClasses} ${roleClasses}`}>
                <div className="text-xs uppercase tracking-wide text-slate-400">
                  {roleLabel} · {turn.created_at}
                </div>
                {turn.role === "coach" ? (
                  <div className="mt-2 space-y-3 text-sm text-slate-100">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="rounded-full border border-slate-700 bg-slate-900/80 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-slate-200">
                        {categoryLabel}
                      </span>
                      <span
                        className={`rounded-full border px-2.5 py-1 text-xs ${badgeClass(
                          deltas?.empathy
                        )}`}
                      >
                        Empathy: {deltas?.empathy ?? 0}
                      </span>
                      <span
                        className={`rounded-full border px-2.5 py-1 text-xs ${badgeClass(
                          deltas?.clarity
                        )}`}
                      >
                        Clarity: {deltas?.clarity ?? 0}
                      </span>
                      <span
                        className={`rounded-full border px-2.5 py-1 text-xs ${badgeClass(
                          deltas?.boundary
                        )}`}
                      >
                        Boundaries: {deltas?.boundary ?? 0}
                      </span>
                      <span
                        className={`rounded-full border px-2.5 py-1 text-xs ${badgeClass(
                          deltas?.escalation
                        )}`}
                      >
                        {METRIC_POLARITY.escalation === "lower_better"
                          ? "Calmness"
                          : "Escalation"}
                        : {deltas?.escalation ?? 0}
                      </span>
                    </div>
                    {showAiDebug &&
                      METRIC_POLARITY.escalation === "lower_better" && (
                        <div className="text-[10px] uppercase tracking-wide text-slate-500">
                          Esc shown as Calmness (inverted)
                        </div>
                      )}
                    <div className="space-y-2 text-sm text-slate-100">
                      {showAiDebug && (
                        <div className="text-[10px] uppercase tracking-wide text-slate-500">
                          DETAILS:{" "}
                          {detailKeys.length > 0
                            ? detailKeys.join("/")
                            : "missing"}
                        </div>
                      )}
                      {coachFields.tip && (
                        <div>
                          <span className="text-xs uppercase tracking-wide text-slate-400">
                            Tip
                          </span>
                          <div>{coachFields.tip}</div>
                        </div>
                      )}
                      {coachFields.why && (
                        <div>
                          <span className="text-xs uppercase tracking-wide text-slate-400">
                            Why
                          </span>
                          <div>{coachFields.why}</div>
                        </div>
                      )}
                      {coachFields.rewrite && (
                        <div>
                          <span className="text-xs uppercase tracking-wide text-slate-400">
                            Rewrite
                          </span>
                          <div>{coachFields.rewrite}</div>
                        </div>
                      )}
                      {coachFields.nextStep && (
                        <div>
                          <span className="text-xs uppercase tracking-wide text-slate-400">
                            Next step
                          </span>
                          <div>{coachFields.nextStep}</div>
                        </div>
                      )}
                      {!coachFields.tip &&
                        !coachFields.why &&
                        !coachFields.rewrite &&
                        !coachFields.nextStep &&
                        (fallbackBody ? (
                          <div>
                            <span className="text-xs uppercase tracking-wide text-slate-400">
                              Coach
                            </span>
                            <div className="whitespace-pre-line">
                              {fallbackBody}
                            </div>
                          </div>
                        ) : (
                          <div className="text-slate-400">
                            Coach feedback unavailable for this turn (using safe
                            defaults).
                          </div>
                        ))}
                    </div>
                  </div>
                ) : (
                  <p className="mt-2 whitespace-pre-line text-sm text-slate-100">
                    {turn.content}
                  </p>
                )}
              </div>
            );
          })}
          {turns.length === 0 && (
            <div className="rounded-xl border border-dashed border-slate-700 p-4 text-sm text-slate-400">
              No turns yet. Start the conversation when ready.
            </div>
          )}
        </div>
        <div className="mt-6 space-y-3">
          <textarea
            value={input}
            onChange={(event) => setInput(event.target.value)}
            className="min-h-[120px] w-full rounded-xl border border-slate-700 bg-slate-950/60 p-3 text-sm text-slate-100"
            placeholder="Type the next facilitator prompt..."
          />
          {showCoachMe && (
            <div className="rounded-2xl border border-slate-800 bg-slate-950/40 p-4">
              <div className="flex items-center justify-between">
                <div className="text-xs font-semibold uppercase tracking-wide text-slate-300">
                  Coach Me
                </div>
                <button
                  type="button"
                  onClick={() => setIsCoachMeOpen((prev) => !prev)}
                  className="text-xs text-slate-400 hover:text-slate-200"
                >
                  {isCoachMeOpen ? "Hide" : "Show"}
                </button>
              </div>
              {isCoachMeOpen && (
                <div className="mt-3 space-y-3">
                  <div className="grid gap-3 sm:grid-cols-2">
                    <label className="text-xs text-slate-300">
                      Metric
                      <select
                        value={coachMeMetric}
                        onChange={(event) =>
                          setCoachMeMetric(
                            event.target.value as typeof coachMeMetric
                          )
                        }
                        className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950/60 p-2 text-xs text-slate-100"
                      >
                        <option value="empathy">Empathy</option>
                        <option value="clarity">Clarity</option>
                        <option value="boundaries">Boundaries</option>
                        <option value="de-escalation">De-escalation</option>
                      </select>
                    </label>
                    <label className="text-xs text-slate-300">
                      Strength
                      <select
                        value={coachMeStrength}
                        onChange={(event) =>
                          setCoachMeStrength(Number(event.target.value) as 1 | 2 | 3)
                        }
                        className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950/60 p-2 text-xs text-slate-100"
                      >
                        <option value={1}>Light (+1)</option>
                        <option value={2}>Medium (+2)</option>
                        <option value={3}>Strong (+3)</option>
                      </select>
                    </label>
                  </div>
                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={handleCoachMeRequest}
                      className="rounded-full bg-slate-200 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-slate-900 transition hover:bg-white disabled:cursor-not-allowed disabled:opacity-60"
                      disabled={coachMeLoading}
                    >
                      {coachMeLoading ? "Loading..." : "Get Coaching Suggestions"}
                    </button>
                    {coachMeError && (
                      <span className="text-xs text-rose-300">
                        {coachMeError}
                      </span>
                    )}
                  </div>
                  {coachMeSuggestions.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {coachMeSuggestions.map((suggestion) => (
                        <button
                          key={suggestion.id}
                          type="button"
                          onClick={() =>
                            setInput((prev) =>
                              prev ? `${prev} ${suggestion.phrase}` : suggestion.phrase
                            )
                          }
                          className="rounded-xl border border-slate-700 bg-slate-900/70 px-3 py-2 text-left text-xs text-slate-100 hover:border-slate-500"
                        >
                          <div>{suggestion.phrase}</div>
                          <div className="mt-1 text-[10px] uppercase tracking-wide text-slate-400">
                            {suggestion.label}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={handleSend}
              className="rounded-full bg-cyan-400 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-slate-950 transition hover:bg-cyan-300 disabled:cursor-not-allowed disabled:opacity-60"
              disabled={isSending || !input.trim()}
            >
              {isSending ? "Sending..." : "Send"}
            </button>
            <button
              type="button"
              onClick={handleEndSession}
              className="rounded-full border border-slate-600 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-slate-100 transition hover:border-slate-400 disabled:cursor-not-allowed disabled:opacity-60"
              disabled={isEnding}
            >
              {isEnding ? "Ending..." : "End Session"}
            </button>
          </div>
        </div>
      </section>
      {showMetricsTuner && (
        <div className="fixed bottom-4 right-4 z-50 w-[280px] rounded-xl border border-white/10 bg-slate-950/80 p-4 shadow-lg backdrop-blur">
          <div className="flex items-center justify-between">
            <div className="text-xs font-semibold uppercase tracking-wide text-slate-200">
              Metrics Tuner (dev)
            </div>
            <button
              type="button"
              onClick={() => setMetricsTunerCollapsed((prev) => !prev)}
              className="text-xs text-slate-400 hover:text-slate-200"
            >
              {metricsTunerCollapsed ? "Expand" : "Collapse"}
            </button>
          </div>
          {!metricsTunerCollapsed && (
            <div className="mt-3 space-y-3 text-xs text-slate-300">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={debugMetricsOverride.enabled}
                  onChange={(event) => handleOverrideToggle(event.target.checked)}
                  className="h-4 w-4 rounded border-slate-600 bg-slate-900 text-cyan-400"
                />
                Override gauges
              </label>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span>Overall</span>
                  <span>{debugMetricsOverride.overall}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={debugMetricsOverride.overall}
                  onChange={(event) =>
                    setDebugMetricsOverride((prev) => ({
                      ...prev,
                      overall: Number(event.target.value),
                      enabled: true
                    }))
                  }
                  className="w-full"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span>Empathy</span>
                  <span>{debugMetricsOverride.empathy}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={debugMetricsOverride.empathy}
                  onChange={(event) =>
                    setDebugMetricsOverride((prev) => ({
                      ...prev,
                      empathy: Number(event.target.value),
                      enabled: true
                    }))
                  }
                  className="w-full"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span>Clarity</span>
                  <span>{debugMetricsOverride.clarity}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={debugMetricsOverride.clarity}
                  onChange={(event) =>
                    setDebugMetricsOverride((prev) => ({
                      ...prev,
                      clarity: Number(event.target.value),
                      enabled: true
                    }))
                  }
                  className="w-full"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span>Boundaries</span>
                  <span>{debugMetricsOverride.boundaries}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={debugMetricsOverride.boundaries}
                  onChange={(event) =>
                    setDebugMetricsOverride((prev) => ({
                      ...prev,
                      boundaries: Number(event.target.value),
                      enabled: true
                    }))
                  }
                  className="w-full"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span>Escalation gauge</span>
                  <span>{debugMetricsOverride.escalation}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={debugMetricsOverride.escalation}
                  onChange={(event) =>
                    setDebugMetricsOverride((prev) => ({
                      ...prev,
                      escalation: Number(event.target.value),
                      enabled: true
                    }))
                  }
                  className="w-full"
                />
              </div>
              <div className="flex flex-wrap gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleOverrideReset}
                  className="rounded-full border border-slate-700 px-3 py-1 text-xs text-slate-200 hover:border-slate-500"
                >
                  Reset to live
                </button>
                <button
                  type="button"
                  onClick={handleOverrideCenter}
                  className="rounded-full border border-slate-700 px-3 py-1 text-xs text-slate-200 hover:border-slate-500"
                >
                  Center all (50)
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
